// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Router } from '@angular/router';
// import { News } from '../News';
// @Injectable({
//   providedIn: 'root'
// })
// export class FavService {
//   constructor(private http: HttpClient, private router: Router) {
//   }
//   addfav(Newsobj:any)
//   {
//     return this.http.post<any>("https://localhost:7035/api/News",Newsobj);
//   }
//   getFavorites(Newsobj:any) {
//     return this.http.get<any>("https://localhost:7035/api/News",Newsobj);
//   }
// }

// fav.service.ts

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { News } from '../News';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FavService {
  private baseUrl: string = "https://localhost:7035/api/News";

  constructor(private http: HttpClient) {}

  addfav(newsObj: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, newsObj);
  }

  getFavorites(): Observable<News[]> {
    return this.http.get<News[]>(this.baseUrl);
  }
}
